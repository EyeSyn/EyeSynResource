salMapArray = [];
salDataArray = [];
normLocArray = [];
imageDimArray = [];
positionArray = [];

inputTextImg = imread(fullFileName);
ocrResults  = ocr(inputTextImg);
recognizedText = ocrResults.Text;    

wordLength = [];
for k=1:length(ocrResults.Words)
    len = length(char(ocrResults.Words(k)));
    wordLength = [wordLength; len];
end

Iocr  = insertObjectAnnotation(inputTextImg, 'rectangle', ...
                   ocrResults.WordBoundingBoxes, ...
                   wordLength,...
                   'Color',{'blue'},'TextColor','blue', ...
                   'TextBoxOpacity', 0, 'FontSize', 12, ...
                   'LineWidth', 2);

wordLength = [];
for k=1:length(ocrResults.Words)
    len = length(char(ocrResults.Words(k)));
    wordLength = [wordLength; len];
end

rawPosition = [ocrResults.WordBoundingBoxes, ...
               wordLength,...
               ocrResults.WordConfidences];
positionArray = [positionArray; rawPosition];

%%%%The outputs of this script are the [x y width height confidence] of the
%%%%detected words bounding box

%%% The first four rows are [x y width height]. 
%%% x y are the upper-left corner of the bounding box in pixel
filtPosition = positionArray(positionArray(:,5)>confidentThrd,1:4);

%%% The following codes are for illustration purpose
%%% obtain the center of the bounding box as the potential fixiation points
newCenterPosition = [(filtPosition(:,1)+filtPosition(:,3)./2),...
                 (filtPosition(:,2)+filtPosition(:,4)./2)];

[maxX, maxY, ~] = size(inputTextImg);

normCenterPositionX = (newCenterPosition(:,1) - 1) / ( maxX - 1 );
normCenterPositionY = (newCenterPosition(:,2) - 1) / ( maxY - 1 );
normCenterPosition = [normCenterPositionX, normCenterPositionY];

[sizePos, ~] =  size(normCenterPosition);

postNew = [newCenterPosition, ones(sizePos,1)];

postFig = insertShape(Iocr, 'Circle', postNew, 'Color', 'red', 'LineWidth', 11);

figure; 
imshow(postFig);
title('');

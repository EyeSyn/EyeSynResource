function [fix, duration] = fixationProByLength(length)

%   Detailed explanation goes here
x = rand;
fix = 0;
    if length == 1 %%%ref. Rayner 1976
        if x<0.077 %%fix for 0.25
            fix=1;
        else      %%skip for 0.75
            fix=0;
        end
        duration = 209;
    elseif length == 0 %%%ref. Rayner 1976
        if x<0.001 %%fix for 0.7
            fix=1;
        else      
            fix=0;
        end
        duration = 0; 
    elseif length == 2 %%%ref. Rayner 1976
        if x<0.501 %%fix for 0.7
            fix=1;
        else      
            fix=0;
        end
        duration = 215;
    elseif length == 3 %%%ref. Rayner 1976
        if x<0.718 %%fix for x<0.318
            fix=1;
        else      
            fix=0;
        end
        duration = 210;
    elseif length == 4
        if x<0.78 %%fix for 48
            fix=1;
        else      
            fix=0;
        end
        duration = 205;
    elseif length == 5 %%%ref. Rayner 1996
        if x<0.80 
            fix=1;
        else      
            fix=0;
        end
        duration = 229;
    elseif length == 6
        if x<0.825 
            fix=1;
        else      
            fix=0;
        end
        duration = 229;
    elseif length == 7
        if x<0.875 
            fix=1;
        else      
            fix=0;
        end
        duration = 249;
    elseif length == 8
        if x<0.915 
            fix=1;
        else      
            fix=0;
        end
        duration = 250;
    elseif length == 9
        if x<0.94
            fix=1;
        else      
            fix=0;
        end
        duration = 253;
    elseif length > 9
        if x<0.925 
            fix=1;
        else      
            fix=0;
        end
        duration = 269;
    end
end


filePattern = fullfile(myFolder, '*.jpg');
imageFiles = dir(filePattern);

numFrames = length(imageFiles);

salMapArray = [];
salDataArray = [];
normLocArray = [];
imageDimArray = [];

rng('shuffle');
selectedRandomIndexArray = randi([1 6], selectedFramesNum, 1, 'uint32');

for index = 1 : selectedFramesNum
    frameIndex = selectedRandomIndexArray(index);
    eval(['baseFileName = ''' num2str(frameIndex) '.png'';']);
    fullFileName = fullfile(myFolder, baseFileName);
    imageArray = imread(fullFileName);
    
    %%%%Rely on the SaliencyToolbox2.3
    [salmap,salData] = runSaliencyMaxDetect(fullFileName);
    imageDim = salmap.origImage.size;
    
    imageDimArray = [imageDimArray; imageDim];

    salmapMatrix = salmap.data;
    featureMatrix = {salData.CM};
    color = featureMatrix(1);
    intense = featureMatrix(2);
    orient = featureMatrix(3);
    colorMatrix = color{1}.data;
    intenseMatrix = intense{1}.data;
    orientMatrix = orient{1}.data;
    
    hLocalMax = vision.LocalMaximaFinder('MaximumNumLocalMaxima',numberOfPotentialFix, ...
                                          'NeighborhoodSize',[5,7], ...
                                          'Threshold',0.1); 

    location = double(hLocalMax(salmapMatrix));
       
    weight = [];
    weightMatrix = salmapMatrix';
    [salMapY, salMapX] = size(salmapMatrix);
    for i=1:size(location)
        weight = [weight;weightMatrix(location(i,1),location(i,2))];
    end
    salLocWeight = [location,weight];
    
    oldLoc = sortrows(salLocWeight,3,'descend');
    
        
    %%%for weighted salmap
    mapCenter = [ceil(salMapX/2), ceil(salMapY/2)];
    
    salLocWeighted = [];
    for i=1:size(salLocWeight)
        distance = ((salLocWeight(i,1)-mapCenter(1))^2+(salLocWeight(i,2)-mapCenter(2))^2)^0.5;
        weightSal = salLocWeight(i,3)*exp(-(distance/4));
        salLocWeighted = [salLocWeighted; salLocWeight(i,1:2), weightSal];   
    end
    
    newLoc = sortrows(salLocWeighted, 3, 'descend');

    salLocWeighted = newLoc;
    
    %%%normlized saliency locations in range 0~1
    normlizedLocationX = salLocWeighted(:,1)./salMapX;
    normlizedLocationY = salLocWeighted(:,2)./salMapY;
    normlizedLocation = [normlizedLocationX, normlizedLocationY, salLocWeighted(:,3)];

    %% convert the norlized locations to the original image pixel range
    convertLocationXPixel = floor(normlizedLocationX.*imageDim(2));
    convertLocationYPixel = floor(normlizedLocationY.*imageDim(1));

    [a, b] = size(normlizedLocation); 
    if a <numberOfPotentialFix
        emptyPending = [ones(numberOfPotentialFix-a,2).*999, zeros(numberOfPotentialFix-a,1)];
        locations = [normlizedLocation;emptyPending];
    else
        locations = normlizedLocation;    
    end 
    
    locations = sortrows(locations, 3, 'descend');
    if frameIndex == 0
%         salMapArray = salmap;
        normLocArray = locations;
    else
%         salMapArray = cat(3, salMapArray, salmap);
        normLocArray = cat(3, normLocArray, locations);
    end
end

%%%%codes for displaying the fixations on frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gazeVector = [];
frameIndex = 1;

for index = 1: selectedFramesNum
     imageIndex = selectedRandomIndexArray(index);
     eval(['baseFileName = ''' num2str(imageIndex) '.png'';']);
     fullFileName = fullfile(myFolder, baseFileName);
     imageArray = imread(fullFileName);
     imageDim = imageDimArray(index,:,:);
     
     frameNormLoc = normLocArray(:,:,index);
     frameNormLoc = frameNormLoc(frameNormLoc(:,1)<999,1:3);
     
     %%%%%%%Dynamic way of selection
     
     prob = (frameNormLoc(:,3));
     selectedFrameNormLoc = [];
     
     for i=1:selectedFix
        [mv, maxLoc] = max(prob);
        selectedFrameNormLoc = [selectedFrameNormLoc;frameNormLoc(maxLoc,1:2)];
        prob(maxLoc) = prob(maxLoc)/1000;  %%used to be 10
     end
    
    %%generate the sythesised gazes
    targetFrameRate = 0.33; %%useless for now
    [gazeWithMicorPertub] = gazeSythesisOnFixationImage(targetFrameRate, samplingFrequency, fullFileName, imageDim, selectedFrameNormLoc);
    gazeVector = cat(1, gazeVector, gazeWithMicorPertub);
end

gazePointNormal = rmoutliers(gazeVector(:,:), 'movmedian', 60);
figure;

plot(gazePointNormal(:,:));
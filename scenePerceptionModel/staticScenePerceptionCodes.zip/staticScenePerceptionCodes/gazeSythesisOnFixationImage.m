function [gazeWithMicorPertub] = gazeSythesisOnFixationImage(targetFrameRate, samplingFrequency, inputImage, imageDim, normlizedLocation)

load fixationPD0215.mat;
 %%%Vector of pilot points
pilotPoints = normlizedLocation;

sceneSizeX = 0.8;
sceneSizeY = 0.8;
distance = 2;
          
pilotPointsPixel = [pilotPoints(:,1).*sceneSizeX, pilotPoints(:,2).*sceneSizeY];          
         
[numberOfPilot,~] = size(pilotPoints);

%%%%%%%% fixation duration
%%%Need better measurements on the fixation statistic
fixDurVector = abs(random(pdFixDurAll, numberOfPilot, 1));
numGazeVector = ceil((fixDurVector./1000).*samplingFrequency);

%%%%%%%%  Pink noise
powerOfInverseFrequency = 0.2;

%%%%%%%%  Normal distribution for saccade jitter
normMu = 0;
normSig = 0.17; %%in the unit of degree %%0.57
normalDistFun = makedist('Normal', 'mu', normMu, 'sigma', normSig);

gazeWithMicorPertub = [];

for i=1:numberOfPilot
    thisPolot = pilotPoints(i,:);
    numGaze = numGazeVector(i);
        
    pinkNoiseFun = dsp.ColoredNoise(powerOfInverseFrequency, numGaze, 1);
    pinkNoiseX =pinkNoiseFun();
    pinkNoiseY =pinkNoiseFun();
   
    normalNoiseX = random(normalDistFun, numGaze, 1);
    normalNoiseY = random(normalDistFun, numGaze, 1);
     
    microPerturbXRadius = (normalNoiseX./60+pinkNoiseX).*0.0174; 
    microPerturbYRadius = (normalNoiseY./60+pinkNoiseY).*0.0174; 
    
    %%arcmin to degree 1 arcmin = 1/60 degree
    microPerturbX = tan(microPerturbXRadius./2).*distance*2; %%perturb in meter
    microPerturbY = tan(microPerturbYRadius./2).*distance*2;
    
    microPerturbNoise = [microPerturbX,microPerturbY];    
    gazePointVector = [ones(numGaze,1)*pilotPointsPixel(i,1) ...
                       ones(numGaze,1)*pilotPointsPixel(i,2)];
                   
    microPerturb = gazePointVector + microPerturbNoise;
    gazeWithMicorPertub = [gazeWithMicorPertub; microPerturb];
end


figure;
imshow(inputImage);
hold on;
plot(floor(gazeWithMicorPertub(:,1).*imageDim(2)),...
      floor(gazeWithMicorPertub(:,2).*imageDim(1)),...
      '-o','Color','k', ...
      'MarkerSize',6,'MarkerFaceColor','c');
plot(floor(pilotPointsPixel(:,1).*imageDim(2)),...
      floor(pilotPointsPixel(:,2).*imageDim(1)),...
      'o',...
      'MarkerSize',6,'MarkerFaceColor','r');
xlim([0, imageDim(2)]);
ylim([0, imageDim(1)]);
hold off;


s = [(gazeWithMicorPertub(:,1)), ...
    (gazeWithMicorPertub(:,2))];
figure
plot(s)
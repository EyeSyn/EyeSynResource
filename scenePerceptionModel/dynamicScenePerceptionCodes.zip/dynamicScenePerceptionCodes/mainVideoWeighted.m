% clc;close all; clear;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%   For dynamic videos   %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
frameIndex = 1;

salMapArray = [];
salDataArray = [];
normLocArray = [];
imageNameIndexArray = [];

filePattern = fullfile(myFolder, '*.png');
imageFiles = dir(filePattern);

numFrames = length(imageFiles);

while frameIndex <= numFrames
    eval(['baseFileName = ''' num2str(frameIndex) '.png'';']);
    fullFileName = fullfile(myFolder, baseFileName);
    imageArray = imread(fullFileName);
    imageNameIndexArray = [imageNameIndexArray;frameIndex];
    
    [salmap,salData] = runSaliencyMaxDetect(fullFileName);
    imageDim = salmap.origImage.size;

    salmapMatrix = salmap.data;
    featureMatrix = {salData.CM};
    color = featureMatrix(1);
    intense = featureMatrix(2);
    orient = featureMatrix(3);
    colorMatrix = color{1}.data;
    intenseMatrix = intense{1}.data;
    orientMatrix = orient{1}.data;

    hLocalMax = vision.LocalMaximaFinder('MaximumNumLocalMaxima',numberOfPotentialFix, ...
                                          'NeighborhoodSize',[3,5], ...
                                          'Threshold',0.1); 

    location = double(hLocalMax(salmapMatrix));
    weight = [];
    weightMatrix = salmapMatrix';
    [salMapY, salMapX] = size(salmapMatrix);
    for i=1:size(location)
        weight = [weight;weightMatrix(location(i,1),location(i,2))];
    end
    salLocWeight = [location,weight];
    
    %%%for weighted salmap
    mapCenter = [ceil(salMapX/2), ceil(salMapY/2)];
    
    salLocWeighted = [];
    for i=1:size(salLocWeight)
        distance = ((salLocWeight(i,1)-mapCenter(1))^2+(salLocWeight(i,2)-mapCenter(2))^2)^0.5;
        weightSal = salLocWeight(i,3)*exp(-distance);
        salLocWeighted = [salLocWeighted; salLocWeight(i,1:2), weightSal];   
    end

     %%%normlized saliency locations in range 0~1
     normlizedLocationX = salLocWeighted(:,1)./salMapX;
     normlizedLocationY = salLocWeighted(:,2)./salMapY;
     normlizedLocation = [normlizedLocationX, normlizedLocationY, salLocWeighted(:,3)];

     %% convert the norlized locations to the original image pixel range
     convertLocationXPixel = floor(normlizedLocationX.*imageDim(2));
     convertLocationYPixel = floor(normlizedLocationY.*imageDim(1));

    [a, b] = size(normlizedLocation); 
    if a <numberOfPotentialFix
        emptyPending = [ones(numberOfPotentialFix-a,2).*999, zeros(numberOfPotentialFix-a,1)];
        normlizedLocation = [normlizedLocation;emptyPending];
    end

    if frameIndex == 0
%         salMapArray = salmap;
        normLocArray = normlizedLocation;
    else
%         salMapArray = cat(3, salMapArray, salmap);
        normLocArray = cat(3, normLocArray, normlizedLocation);
    end

    frameIndex = frameIndex+stepLength;
end

%%%%codes for displaying the fixations on frames
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gazeVector = [];
frameIndex = 1;

recordLoc = [];
previousLocX = 0;
previousLocY = 0;

for index = 1: length(imageNameIndexArray)
     imageIndex = imageNameIndexArray(index);
     eval(['baseFileName = ''' num2str(imageIndex) '.png'';']);
     fullFileName = fullfile(myFolder, baseFileName);
     imageArray = imread(fullFileName);
     
     frameNormLoc = normLocArray(:,:,index);
     frameNormLoc = frameNormLoc(frameNormLoc(:,1)<999,:);
     %%%find the loc with highest score
     [val, index] = max(frameNormLoc(:,3));
     selectedFrameNormLoc = frameNormLoc(index,1:2);
 
    recordLoc = [recordLoc; previousLocX, previousLocY];
    %%generate the sythesised gazes
    [gazeWithMicorPertub] = gazeSythesisOnFixation(samplingFrequency,selectedFrameNormLoc);
    gazeVector = cat(1, gazeVector, gazeWithMicorPertub);
end

gazePointNormal = rmoutliers(gazeVector(:,:), 'movmedian', 60);
figure;
plot(gazePointNormal);
function [gazeWithMicorPertub] = gazeSythesisOnFixation(samplingFrequency,normlizedLocation) 
 %%%Vector of pilot points
pilotPoints = normlizedLocation;

load fixationPD0215.mat;

sceneSizeX = 0.8;
sceneSizeY = 0.8;
distance = 1.5;
          
pilotPointsPixel = [pilotPoints(:,1).*sceneSizeX, pilotPoints(:,2).*sceneSizeY];          
[numberOfPilot,~] = size(pilotPoints);

%%%%%%%% fixation duration
%%%Need better measurements on the fixation statistic
% fixationDurFun = makedist('Normal', 'mu', 1.081, 'sigma', 2.9016);
%%%%%for video
fixDurVector = abs(random(pdFixDurPerFrame, numberOfPilot, 1));
%%%%%static 
numGazeVector = ceil((fixDurVector./1000).*samplingFrequency);

%%%%%%%%  Pink noise
powerOfInverseFrequency = 0.6;

%%%%%%%%  Normal distribution for saccade jitter
normMu = 0;
normSig = 1.07; %%in the unit of degree
normalDistFun = makedist('Normal', 'mu', normMu, 'sigma', normSig);

gazeWithMicorPertub = [];

for i=1:numberOfPilot
    thisPolot = pilotPoints(i,:);
    numGaze = numGazeVector(i);
    
    pinkNoiseFun = dsp.ColoredNoise(powerOfInverseFrequency, numGaze, 1);
    pinkNoiseX =pinkNoiseFun();
    pinkNoiseY =pinkNoiseFun();
   
    normalNoiseX = random(normalDistFun, numGaze, 1);
    normalNoiseY = random(normalDistFun, numGaze, 1);
    
    microPerturbXRadius = (normalNoiseX./60+pinkNoiseX).*0.0174; 
    microPerturbYRadius = (normalNoiseY./60+pinkNoiseY).*0.0174; 
    
    %%arcmin to degree 1 arcmin = 1/60 degree
    microPerturbX = tan(microPerturbXRadius./2).*distance; %%perturb in meter
    microPerturbY = tan(microPerturbYRadius./2).*distance;
    
    microPerturbNoise = [microPerturbX,microPerturbY];    
    gazePointVector = [ones(numGaze,1)*pilotPointsPixel(i,1) ...
                       ones(numGaze,1)*pilotPointsPixel(i,2)];
                   
    microPerturb = gazePointVector + microPerturbNoise;
    gazeWithMicorPertub = [gazeWithMicorPertub; microPerturb];
end
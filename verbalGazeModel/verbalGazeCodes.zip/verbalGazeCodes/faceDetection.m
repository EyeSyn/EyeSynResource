% clear;close all; clc;

% Create a cascade detector object.
faceDetector = vision.CascadeObjectDetector();
EyeDetect = vision.CascadeObjectDetector('EyePairBig');
MouthDetect = vision.CascadeObjectDetector('Mouth');
NoseDetect = vision.CascadeObjectDetector('Nose');

preEyes = [];
preMouth = [];
preNose = [];

mouth = [];
detectedFlag = 0;
detectedMouthFlag = 0;
detectedNoseFlag = 0;

eyeArray = [];
mouthArray = [];
noseArray = [];

frameIndex = 1;
while hasFrame(videoReader)
    videoFrame = readFrame(videoReader);
    Face       = step(faceDetector, videoFrame);
    [frameY, frameX,~] = size(videoFrame);
    
    %To detect Eye
    Eyes=step(EyeDetect,videoFrame);
    [numEyePositions,~] = size(Eyes);
    if numEyePositions == 0
        eyes = preEyes;
        if detectedFlag == 0
            continue
        end
    else
        eyes = Eyes(1,:);
        detectedFlag = 1;
    end
    preEyes = eyes;
    eyeCenter = [eyes(1)+eyes(3)/2,eyes(2)+eyes(4)/2, 5];
    
    %To detect nose
    Nose=step(NoseDetect,videoFrame);
    [numNosePositions,~] = size(Nose);
    if numNosePositions == 0
        nose = preNose;
        if detectedNoseFlag == 0
            continue
        end
    else
        nose = Nose(1,:);
        detectedNoseFlag = 1;
    end
    preNose = nose;
    noseCenter = [nose(1)+nose(3)/2,nose(2)+nose(4)/2, 5];
    
    %%%% To detect mouth
    Mouth=step(MouthDetect,videoFrame);
    [numMouthPositions,~] = size(Mouth);
%     mouth = Mouth(1,:);
    
    if numMouthPositions == 0
        mouth = preMouth;
    else
        for i=1:numMouthPositions
            if Mouth(i,1) < (eyes(1)+eyes(3))
                if Mouth(i,1) > (eyes(1))
                    if Mouth(i,2) > (eyes(2)+eyes(4))
                        mouth = Mouth(i,:);
                        detectedMouthFlag = 1;
                        break
                    end
                end
            end
        end
%         mouth = preMouth;
    end
    
    if detectedMouthFlag ==0 
        continue
    end
    
    preMouth = mouth;
    mouthCenter = [mouth(1)+mouth(3)/2,mouth(2)+mouth(4)/2, 5];
    
%     videoFrame = insertShape(videoFrame, 'Rectangle', Face);
    videoFrame = insertShape(videoFrame, 'Rectangle', eyes, 'Color', 'red', 'LineWidth',3);
    videoFrame = insertShape(videoFrame, 'Circle', eyeCenter, 'Color', 'red', 'LineWidth',3);
    videoFrame = insertShape(videoFrame, 'Rectangle', mouth, 'Color', 'blue', 'LineWidth',3);
    videoFrame = insertShape(videoFrame, 'Circle', mouthCenter, 'Color', 'blue', 'LineWidth',3);
    videoFrame = insertShape(videoFrame, 'Rectangle', nose, 'Color', 'yellow', 'LineWidth',3);
    videoFrame = insertShape(videoFrame, 'Circle', noseCenter, 'Color', 'yellow', 'LineWidth',3);
    
    % Display the detected points.
    figure(1), imshow(videoFrame), hold on;
    hold off;
    
    %%
    normlizedMouthCenterX = mouthCenter(1)./frameX;
    normlizedMouthCenterY = mouthCenter(2)./frameY;
    normlizedMouth = [normlizedMouthCenterX, normlizedMouthCenterY];
    
    normlizedEyesCenterX = eyeCenter(1)./frameX;
    normlizedEyesCenterY = eyeCenter(2)./frameY;
    normlizedEye = [normlizedEyesCenterX, normlizedEyesCenterY];
    
    normlizedNoseCenterX = noseCenter(1)./frameX;
    normlizedNoseCenterY = noseCenter(2)./frameY;
    normlizedNose = [normlizedNoseCenterX, normlizedNoseCenterY];

    eyeArray = [eyeArray;normlizedEye];
    mouthArray = [mouthArray;normlizedMouth];
    noseArray = [noseArray;normlizedNose];

    frameIndex = frameIndex+1;
end

gaze_frequency = samplingFrequency;

gazeVectorCombine = [];

eyeArray = 0-eyeArray+1;
mouthArray = 0-mouthArray+1;
noseArray = 0-noseArray+1;

fixArray = [eyeArray, mouthArray, noseArray];
fixArray = rmoutliers(fixArray(:,:), 'movmedian', 60);

%%%%three states MKC
stateTranMat = [0.8 0.10 0.10; 0.55 0.36 0.09; 0.65 0.1 0.25];
statenames = ["eyes" "mouth" "nose"];

distFunIEI_Eye = makedist('Normal', 'mu', 2.27, 'sigma', 1.07);
distFunIEI_Mouth = makedist('Normal', 'mu', 2.07, 'sigma', 1.52);
distFunIEI_Nose = makedist('Normal', 'mu', 0.65, 'sigma', 0.22);

mc = dtmc(stateTranMat, 'StateNames', statenames);

numSteps = length(fixArray);
numOfWalks = 9000; %this is a large number > numSteps

randomWalkSequence = simulate(mc, numOfWalks);
randomWalkSequence = [1; randomWalkSequence];

selectedFix = [];
selectedStateDur = [];
currentStep = 1;
walkIndex = 1;

while currentStep < numSteps
    if randomWalkSequence(walkIndex) == 1
        %random sample the event duration
        eventTime = abs(random(distFunIEI_Eye, 1, 1));
        %calculated the number of gazes within this event 
        numOfFrameInEvent = floor(eventTime/(1/gaze_frequency)); 
        endStep = currentStep+numOfFrameInEvent-1;
        stateDur = ones(numOfFrameInEvent,1)*1;

        if endStep >= numSteps
            endStep = numSteps;
        end 

        fix = fixArray(currentStep:endStep,1:2);
        currentStep = endStep;

    elseif randomWalkSequence(walkIndex) == 2
        %random sample the event duration
        eventTime = abs(random(distFunIEI_Mouth, 1, 1));
        %calculated the number of gazes within this event 
        numOfFrameInEvent = floor(eventTime/(1/gaze_frequency)); 
        endStep = currentStep+numOfFrameInEvent-1;
        stateDur = ones(numOfFrameInEvent,1)*2;

        if endStep >= numSteps
            endStep = numSteps;
        end 

        fix = fixArray(currentStep:endStep,3:4);
        currentStep = endStep;
    else
        %random sample the event duration
        eventTime = abs(random(distFunIEI_Nose, 1, 1));
        %calculated the number of gazes within this event 
        numOfFrameInEvent = floor(eventTime/(1/gaze_frequency)); 
        endStep = currentStep+numOfFrameInEvent-1;
        stateDur = ones(numOfFrameInEvent,1)*3;

        if endStep >= numSteps
            endStep = numSteps;
        end 

        fix = fixArray(currentStep:endStep,5:6);
        currentStep = endStep;
    end
    walkIndex = walkIndex + 1;
    selectedFix = [selectedFix; fix];
    selectedStateDur = [selectedStateDur; stateDur];
end

gazeVector = [];
for index = 1:length(selectedFix)
    [gazeWithMicorPertub] = gazeSythesisOnFixation(selectedFix(index,1:2), samplingFrequency);
    gazeVector = cat(1, gazeVector, gazeWithMicorPertub);
end

gazeVectorCombine = [gazeVectorCombine; gazeVector];

gazeVector = normalize(gazeVectorCombine(:,:),'range');
gazeVector = rmoutliers(gazeVector(:,:), 'movmedian', 60);
gazeVector = normalize(gazeVector(:,:),'range');


numGaze = 3000;

figure
plot(gazeVector(1:end,:))
xlabel('Gaze index');
ylabel('Coordinate');
% ylim([0 1]);
% xlim([1 end]);

walkEye = randomWalkSequence;
for i=1:walkIndex
    if walkEye(i) == 1
        walkEye(i) = 1;
    else
        walkEye(i) = 0;
    end
end

walkNose = randomWalkSequence;
for i=1:walkIndex
    if walkNose(i) == 3
        walkNose(i) = 3;
    else
        walkNose(i) = 0;
    end
end

walkMouth = randomWalkSequence;
for i=1:walkIndex
    if walkMouth(i) == 2
        walkMouth(i) = 2;
    else
        walkMouth(i) = 0;
    end
end


figure
subplot(4,1,1)
plot(walkEye(1:walkIndex)); hold on;
plot(walkNose(1:walkIndex));
plot(walkMouth(1:walkIndex));
xlabel('Walk index');
ylabel('Selected state');
ylim([-0.1 3.1]);
xlim([0 walkIndex+1]);

subplot(4,1,2)
plot(selectedStateDur(1:numGaze));
xlabel('S index');
ylabel('Selected state');
ylim([-0.1 3.1]);
xlim([0 numGaze+1]);

subplot(4,1,3)
plot(selectedFix(1:numGaze,:))
xlabel('Gaze index');
ylabel('Coordinate');
ylim([0 1]);
xlim([1 numGaze]);

subplot(4,1,4)
plot(gazeVector(1:numGaze,:))
xlabel('Gaze index');
ylabel('Coordinate');
ylim([0 1]);
xlim([1 numGaze]);